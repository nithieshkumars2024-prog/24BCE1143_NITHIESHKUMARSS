const express = require("express");
const mongoose = require("mongoose");

const User = require("./models/User");

const app = express();

app.use(express.json());

mongoose.connect(
    "mongodb://127.0.0.1:27017/ghostpassdb"
)
.then(() => {
    console.log("MongoDB Connected");
})
.catch(err => {
    console.log(err);
});

app.post("/users", async (req,res)=>{

    const user = await User.create(req.body);

    res.status(201).json(user);

});

app.get("/users", async (req,res)=>{

    const users = await User.find();

    res.json(users);

});

app.put("/users/:id", async (req,res)=>{

    try {

        const user = await User.findOne({
            _id: req.params.id
        });

        if(!user){
            return res.status(404).json({
                message: "User not found"
            });
        }

        if(req.body.username){
            user.username = req.body.username;
        }

        if(req.body.password){
            user.password = req.body.password;
        }

        if(req.body.captcha){
            user.captcha = req.body.captcha;
        }

        await user.save();

        res.json(user);

    } catch(err){

        console.log(err);

        res.status(500).json({
            message:"Server Error"
        });

    }

});

app.delete("/users/:username", async(req,res)=>{

    try{

        const result = await User.deleteOne({
            username:req.params.username
        });

        res.json(result);

    }
    catch(err){

        console.log(err);

        res.status(500).json({
            message:"Server Error"
        });

    }

});

app.listen(5000, ()=>{

    console.log(
        "Server running on port 5000"
    );

});

function generateCaptcha(){

    const chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    let captcha="";

    for(let i=0;i<5;i++){

        captcha +=
        chars[Math.floor(
            Math.random()*chars.length
        )];
    }

    return captcha;
}

app.get("/captcha",(req,res)=>{

    const captcha =
    generateCaptcha();

    res.json({
        captcha
    });

});

app.post("/login",

async(req,res)=>{

    const {
        username,
        password,
        captcha
    } = req.body;

    const user =
    await User.findOne({
        username
    });

    if(!user){

        return res.json({
            message:"User Not Found"
        });
    }

    if(user.isLocked){

        return res.json({
            message:"Account Locked"
        });
    }

    if(
        user.password !== password ||
        user.captcha !== captcha
    ){

        user.failedAttempts++;

        if(
            user.failedAttempts >=3
        ){
            user.isLocked=true;
        }

        await user.save();

        return res.json({
            message:"Invalid Login"
        });
    }

    user.failedAttempts=0;

    await user.save();

    res.json({
        message:"Login Success"
    });

});

app.put(
"/reset/:id",

async(req,res)=>{

    const user =
    await User.findByIdAndUpdate(

        req.params.id,

        {
            failedAttempts:0
        },

        {
            new:true
        }
    );

    res.json(user);

});

app.put(
"/unlock/:id",

async(req,res)=>{

    const user =
    await User.findByIdAndUpdate(

        req.params.id,

        {
            isLocked:false,
            failedAttempts:0
        },

        {
            new:true
        }
    );

    res.json(user);

});