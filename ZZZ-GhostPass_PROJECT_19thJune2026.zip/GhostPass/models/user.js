const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({

    username:{
        type:String,
        unique:true
    },

    password:String,

    captcha:String,

    failedAttempts:{
        type:Number,
        default:0
    },

    isLocked:{
        type:Boolean,
        default:false
    }

});

module.exports = mongoose.model("User",UserSchema);